import p1 from "@/assets/p1.jpg";
import p2 from "@/assets/p2.jpg";
import p3 from "@/assets/p3.jpg";
import p4 from "@/assets/p4.jpg";

export const WEIGHTS = [
  { grams: 5, price: 30 },
  { grams: 10, price: 60 },
  { grams: 50, price: 190 },
  { grams: 100, price: 350 },
] as const;

export type Product = { id: string; name: string; tag: string; img: string; cbd: string; desc: string; notes: string };

export const PRODUCTS: Product[] = [
  { id: "lapin", name: "Lapin Blanc", tag: "Fleur", img: p1, cbd: "CBD 12%", desc: "Une fleur indoor dense et givrée, cultivée avec soin.", notes: "Agrumes · Pin · Terre" },
  { id: "chat", name: "Chat du Cheshire", tag: "Fleur", img: p2, cbd: "CBD 15%", desc: "Des reflets violets et un parfum envoûtant qui vous fera sourire.", notes: "Fruits rouges · Raisin" },
  { id: "chapelier", name: "Chapelier Fou", tag: "Résine", img: p3, cbd: "CBD 20%", desc: "Une résine dorée, souple et aromatique.", notes: "Épices · Miel · Bois" },
  { id: "reine", name: "Reine de Cœur", tag: "Fleur", img: p4, cbd: "CBD 10%", desc: "Une fleur légère et fraîche pour des moments doux.", notes: "Citron vert · Herbe fraîche" },
];
