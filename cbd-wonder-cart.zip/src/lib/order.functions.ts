import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const schema = z.object({
  firstName: z.string().trim().min(1).max(60),
  phone: z.string().trim().min(6).max(20),
  address: z.string().trim().min(3).max(200),
  department: z.string().trim().min(2).max(3),
  city: z.string().trim().min(1).max(80),
  time: z.string().trim().min(1).max(40),
  items: z
    .array(z.object({ name: z.string().max(80), grams: z.number(), price: z.number(), qty: z.number().int().min(1).max(50) }))
    .min(1)
    .max(50),
});

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export const sendOrder = createServerFn({ method: "POST" })
  .inputValidator((d) => schema.parse(d))
  .handler(async ({ data }) => {
    const LOVABLE_API_KEY = process.env['LOVABLE_API_KEY'];
    const TELEGRAM_API_KEY = process.env['TELEGRAM_API_KEY'];
    const chatId = process.env['TELEGRAM_CHAT_ID'] || "@pdm91_off";
    if (!LOVABLE_API_KEY || !TELEGRAM_API_KEY) {
      return { ok: false, error: "Telegram n'est pas encore connecté." };
    }
    const total = data.items.reduce((s, i) => s + i.price * i.qty, 0);
    const lines = data.items.map((i) => `• ${esc(i.name)} — ${i.grams}g x${i.qty} = ${i.price * i.qty}€`).join("\n");
    const text = `🍄 <b>Nouvelle commande</b>\n\n${lines}\n\n<b>Total : ${total}€</b>\n\n👤 ${esc(data.firstName)}\n📞 ${esc(data.phone)}\n📍 ${esc(data.address)}, ${esc(data.department)} ${esc(data.city)}\n🕐 ${esc(data.time)}`;
    const res = await fetch("https://connector-gateway.lovable.dev/telegram/sendMessage", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "X-Connection-Api-Key": TELEGRAM_API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML" }),
    });
    if (!res.ok) {
      const body = await res.text();
      console.error(`Telegram failed [${res.status}]: ${body}`);
      return { ok: false, error: "L'envoi a échoué, réessaie." };
    }
    return { ok: true };
  });
