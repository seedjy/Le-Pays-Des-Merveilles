import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { PRODUCTS, WEIGHTS, type Product } from "@/lib/shop";
import { sendOrder } from "@/lib/order.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Le Pays Des Merveilles — Boutique CBD" },
      { name: "description", content: "Fleurs et résines CBD premium livrées chez vous. Commandez en quelques clics." },
      { property: "og:title", content: "Le Pays Des Merveilles — Boutique CBD" },
      { property: "og:description", content: "Fleurs et résines CBD premium livrées chez vous." },
    ],
  }),
  component: Shop,
});

type CartItem = { id: string; name: string; grams: number; price: number; qty: number };
type Review = { name: string; stars: number; text: string };

const SEED: Review[] = [
  { name: "Alice", stars: 5, text: "Qualité incroyable, livraison rapide !" },
  { name: "Mathis", stars: 5, text: "Le Chat du Cheshire est une merveille." },
  { name: "Inès", stars: 4, text: "Très bon produit, je recommande." },
];

function Stars({ n, size = "text-base" }: { n: number; size?: string }) {
  return (
    <span className={`${size} tracking-tight`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <span key={i} className={i <= Math.round(n) ? "text-gold" : "text-muted-foreground/40"}>★</span>
      ))}
    </span>
  );
}

function Sheet({ open, onClose, children, title }: { open: boolean; onClose: () => void; children: React.ReactNode; title: string }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <button aria-label="Fermer" className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={onClose} />
      <div className="sheet-in relative max-h-[92vh] w-full overflow-y-auto rounded-t-3xl border border-gold/30 bg-card p-5 pb-8 sm:max-w-md sm:rounded-3xl">
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-muted-foreground/40 sm:hidden" />
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="font-display text-2xl text-gold">{title}</h2>
          <button onClick={onClose} className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-muted text-foreground">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Shop() {
  const [reviews, setReviews] = useState<Review[]>(SEED);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [product, setProduct] = useState<Product | null>(null);
  const [weight, setWeight] = useState(0);
  const [view, setView] = useState<null | "reviews" | "cart" | "checkout" | "done">(null);

  useEffect(() => {
    const r = localStorage.getItem("pdm-reviews");
    if (r) setReviews(JSON.parse(r));
  }, []);

  const avg = reviews.reduce((s, r) => s + r.stars, 0) / reviews.length;
  const count = cart.reduce((s, i) => s + i.qty, 0);
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);

  const add = () => {
    if (!product) return;
    const w = WEIGHTS[weight] ?? WEIGHTS[0];
    const key = `${product.id}-${w.grams}`;
    setCart((c) => {
      const ex = c.find((i) => i.id === key);
      if (ex) return c.map((i) => (i.id === key ? { ...i, qty: i.qty + 1 } : i));
      return [...c, { id: key, name: product.name, grams: w.grams, price: w.price, qty: 1 }];
    });
    setProduct(null);
  };

  const changeQty = (id: string, d: number) =>
    setCart((c) => c.map((i) => (i.id === id ? { ...i, qty: i.qty + d } : i)).filter((i) => i.qty > 0));

  return (
    <div className="wonder-bg min-h-screen pb-28">
      <header className="px-5 pb-6 pt-10 text-center">
        <h1 className="font-display text-5xl leading-[0.95] text-gold-gradient sm:text-6xl">

          Le Pays<br />Des Merveilles
        </h1>
        <button
          onClick={() => setView("reviews")}
          className="mt-6 inline-flex items-center gap-2 rounded-full border border-gold/40 bg-card/60 px-5 py-2.5 backdrop-blur transition active:scale-95"
        >
          <Stars n={avg} />
          <span className="font-semibold text-foreground">{avg.toFixed(1)}</span>
          <span className="text-sm text-muted-foreground">· {reviews.length} avis</span>
        </button>
      </header>

      <main className="mx-auto grid max-w-3xl grid-cols-2 gap-3 px-4 sm:gap-5 md:grid-cols-3">
        {PRODUCTS.map((p) => (
          <button
            key={p.id}
            onClick={() => { setProduct(p); setWeight(0); }}
            className="group overflow-hidden rounded-2xl border border-gold/20 bg-card text-left transition active:scale-[0.97]"
          >
            <div className="aspect-[4/5] overflow-hidden">
              <img src={p.img} alt={p.name} loading="lazy" width={816} height={816} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
            </div>
            <div className="p-3">
              <p className="text-[10px] uppercase tracking-widest text-gold/80">{p.tag} · {p.cbd}</p>
              <h3 className="font-display truncate text-lg text-foreground">{p.name}</h3>
              <p className="text-sm text-muted-foreground">dès <span className="font-semibold text-gold">30€</span></p>
            </div>
          </button>
        ))}
      </main>

      {count > 0 && (
        <button
          onClick={() => setView("cart")}
          className="sheet-in fixed inset-x-4 bottom-5 z-40 mx-auto flex max-w-md items-center justify-between rounded-full bg-gold px-6 py-4 font-semibold text-primary-foreground shadow-gold"
        >
          <span>🧺 Panier · {count}</span>
          <span>{total}€</span>
        </button>
      )}

      <Sheet open={!!product} onClose={() => setProduct(null)} title={product?.name ?? ""}>
        {product && (
          <>
            <img src={product.img} alt={product.name} width={816} height={816} className="mb-4 aspect-video w-full rounded-2xl object-cover" />
            <p className="text-xs uppercase tracking-widest text-gold/80">{product.tag} · {product.cbd}</p>
            <p className="mt-2 text-foreground">{product.desc}</p>
            <p className="mt-1 text-sm text-muted-foreground">Arômes : {product.notes}</p>
            <p className="mt-5 mb-2 text-sm font-semibold text-foreground">Choisis ton grammage</p>
            <div className="grid grid-cols-2 gap-2">
              {WEIGHTS.map((w, i) => (
                <button
                  key={w.grams}
                  onClick={() => setWeight(i)}
                  className={`rounded-xl border px-3 py-3 text-center transition ${i === weight ? "border-gold bg-gold/15 text-gold" : "border-border text-foreground"}`}
                >
                  <div className="font-semibold">{w.grams}g</div>
                  <div className="text-sm opacity-80">{w.price}€</div>
                </button>
              ))}
            </div>
            <button onClick={add} className="mt-5 w-full rounded-full bg-gold py-4 font-semibold text-primary-foreground shadow-gold">
              Ajouter au panier · {(WEIGHTS[weight] ?? WEIGHTS[0]).price}€
            </button>
          </>
        )}
      </Sheet>

      <Sheet open={view === "reviews"} onClose={() => setView(null)} title="Avis clients">
        <ReviewForm onSubmit={(r) => { const n = [r, ...reviews]; setReviews(n); localStorage.setItem("pdm-reviews", JSON.stringify(n)); }} />
        <div className="mt-5 space-y-3">
          {reviews.map((r, i) => (
            <div key={i} className="rounded-xl bg-muted p-3">
              <div className="flex items-center justify-between gap-2">
                <span className="truncate font-semibold text-foreground">{r.name}</span>
                <Stars n={r.stars} size="text-sm" />
              </div>
              {r.text && <p className="mt-1 text-sm text-muted-foreground">{r.text}</p>}
            </div>
          ))}
        </div>
      </Sheet>

      <Sheet open={view === "cart"} onClose={() => setView(null)} title="Ton panier">
        {cart.length === 0 ? (
          <p className="text-muted-foreground">Ton panier est vide.</p>
        ) : (
          <>
            <div className="space-y-3">
              {cart.map((i) => (
                <div key={i.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-xl bg-muted p-3">
                  <div className="min-w-0">
                    <p className="truncate font-semibold text-foreground">{i.name}</p>
                    <p className="text-sm text-muted-foreground">{i.grams}g · {i.price * i.qty}€</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => changeQty(i.id, -1)} className="h-8 w-8 rounded-full border border-border text-foreground">−</button>
                    <span className="w-5 text-center text-foreground">{i.qty}</span>
                    <button onClick={() => changeQty(i.id, 1)} className="h-8 w-8 rounded-full border border-border text-foreground">+</button>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-5 flex justify-between text-lg">
              <span className="text-foreground">Total</span>
              <span className="font-semibold text-gold">{total}€</span>
            </div>
            <button onClick={() => setView("checkout")} className="mt-4 w-full rounded-full bg-gold py-4 font-semibold text-primary-foreground shadow-gold">
              Commander
            </button>
          </>
        )}
      </Sheet>

      <Sheet open={view === "checkout"} onClose={() => setView(null)} title="Livraison">
        <Checkout cart={cart} total={total} onDone={() => { setCart([]); setView("done"); }} />
      </Sheet>

      <Sheet open={view === "done"} onClose={() => setView(null)} title="Merci ! 🍄">
        <p className="text-foreground">Ta commande a bien été envoyée. Nous te contactons très vite pour confirmer la livraison.</p>
      </Sheet>
    </div>
  );
}

function ReviewForm({ onSubmit }: { onSubmit: (r: Review) => void }) {
  const [stars, setStars] = useState(5);
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [sent, setSent] = useState(false);
  if (sent) return <p className="rounded-xl bg-gold/15 p-3 text-gold">Merci pour ton avis ✨</p>;
  return (
    <form
      onSubmit={(e) => { e.preventDefault(); if (!name.trim()) return; onSubmit({ name: name.trim().slice(0, 40), stars, text: text.trim().slice(0, 300) }); setSent(true); }}
      className="space-y-3 rounded-2xl border border-gold/30 p-4"
    >
      <p className="text-sm font-semibold text-foreground">Laisse ton avis</p>
      <div className="flex gap-1 text-3xl">
        {[1, 2, 3, 4, 5].map((i) => (
          <button type="button" key={i} onClick={() => setStars(i)} className={i <= stars ? "text-gold" : "text-muted-foreground/40"}>★</button>
        ))}
      </div>
      <input className="field" placeholder="Ton prénom" value={name} onChange={(e) => setName(e.target.value)} />
      <textarea className="field min-h-20" placeholder="Ton commentaire (optionnel)" value={text} onChange={(e) => setText(e.target.value)} />
      <button className="w-full rounded-full bg-gold py-3 font-semibold text-primary-foreground">Publier</button>
    </form>
  );
}

function Checkout({ cart, total, onDone }: { cart: CartItem[]; total: number; onDone: () => void }) {
  const send = useServerFn(sendOrder);
  const [f, setF] = useState({ firstName: "", phone: "", address: "", department: "", city: "", time: "" });
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    if (Object.values(f).some((v) => !v.trim())) return setErr("Merci de remplir tous les champs.");
    setLoading(true);
    try {
      const r = await send({ data: { ...f, items: cart.map(({ name, grams, price, qty }) => ({ name, grams, price, qty })) } });
      if (r.ok) onDone();
      else setErr(r.error ?? "Erreur");
    } catch {
      setErr("Vérifie tes informations et réessaie.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-3">
      <input className="field" placeholder="Prénom" value={f.firstName} onChange={set("firstName")} autoComplete="given-name" />
      <input className="field" placeholder="Numéro de téléphone" type="tel" value={f.phone} onChange={set("phone")} autoComplete="tel" />
      <input className="field" placeholder="Adresse de livraison" value={f.address} onChange={set("address")} autoComplete="street-address" />
      <div className="grid grid-cols-[6rem_minmax(0,1fr)] gap-3">
        <input className="field" placeholder="Dépt." inputMode="numeric" maxLength={3} value={f.department} onChange={set("department")} />
        <input className="field" placeholder="Ville" value={f.city} onChange={set("city")} autoComplete="address-level2" />
      </div>
      <label className="block text-sm text-muted-foreground">Heure de livraison</label>
      <input className="field" type="time" value={f.time} onChange={set("time")} />
      {err && <p className="text-sm text-destructive">{err}</p>}
      <button disabled={loading} className="w-full rounded-full bg-gold py-4 font-semibold text-primary-foreground shadow-gold disabled:opacity-60">
        {loading ? "Envoi…" : `Validez la commande · ${total}€`}
      </button>
    </form>
  );
}
